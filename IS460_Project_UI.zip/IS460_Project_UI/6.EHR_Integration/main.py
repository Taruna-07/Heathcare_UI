from tkinter import Tk, Label, Frame, Button, Entry, Text, Scrollbar
from flask import Flask

app6 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("EHR Integration - Patient Data")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Unified Patient Data", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create search frame
search_frame = Frame(root, bg=BG_COLOR)
search_frame.pack(fill="x")

# Create patient ID label and entry
patient_id_label = Label(search_frame, text="Patient ID:", bg=BG_COLOR, fg=TEXT_COLOR)
patient_id_label.pack(side="left", padx=10)

patient_id_entry = Entry(search_frame, width=20, bg=BG_COLOR, fg=TEXT_COLOR)
patient_id_entry.pack(side="left", padx=10)

# Create search button
search_button = Button(search_frame, text="Search", bg=ACCENT_COLOR, fg=TEXT_COLOR)
search_button.pack(side="left", padx=10)

# Create data frame
data_frame = Frame(root, bg=BG_COLOR)
data_frame.pack(fill="both", expand=True)

# Create scrollbar
scrollbar = Scrollbar(data_frame, orient="vertical")
scrollbar.pack(side="right", fill="y")

# Create patient data text box
patient_data_text = Text(data_frame, wrap="word", bg=BG_COLOR, fg=TEXT_COLOR, yscrollcommand=scrollbar.set)
patient_data_text.pack(fill="both", expand=True)

# Configure scrollbar
scrollbar.config(command=patient_data_text.yview)

# Sample patient data
sample_data = """
**Patient:** John Smith
**ID:** 1234567890
**Age:** 35
**Address:** 123 Main Street, Anytown, USA
**Phone:** (555) 555-5555
**Email:** john.smith@email.com

**Medical history:**
* Hypertension
* Diabetes
* Asthma

**Medications:**
* Lisinopril 20mg daily
* Metformin 500mg twice daily
* Albuterol inhaler as needed

**Allergies:**
* Penicillin
* Sulfa drugs

**Recent appointments:**
* 2023-12-05: Dr. Jane Doe - General checkup
* 2023-11-15: Dr. Mark Lee - Cardiology consultation

**Upcoming appointments:**
* 2023-12-20: Dr. Sarah Jones - Ophthalmology appointment
"""

# Add sample data to text box
patient_data_text.insert("end", sample_data)

# Create transition frame
transition_frame = Frame(root, bg=BG_COLOR)
transition_frame.pack(fill="x", side="bottom")

# Create transition button
transition_button = Button(transition_frame, text="Open Chat", bg=ACCENT_COLOR, fg=TEXT_COLOR)
transition_button.pack(side="left", padx=10)

# Start the main event loop
root.mainloop()
