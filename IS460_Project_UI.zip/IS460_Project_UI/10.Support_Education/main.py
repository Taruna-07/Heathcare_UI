from tkinter import Tk, Label, Frame, Button, Listbox, Scrollbar, Text, Radiobutton, IntVar
from flask import Flask

app10 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Support & Education")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Support & Education", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create sections frame
sections_frame = Frame(root, bg=BG_COLOR)
sections_frame.pack(fill="both", expand=True)

# Create training programs section
training_frame = Frame(sections_frame, bg=BG_COLOR, bd=1, relief="groove")
training_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

# Training programs label
training_label = Label(training_frame, text="Training Programs", font=("Arial", 14, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
training_label.pack(pady=5)

# Training programs list with scrollbar
training_listbox = Listbox(training_frame, bg=BG_COLOR, fg=TEXT_COLOR, selectmode="SINGLE")
training_listbox.pack(fill="both", expand=True)

# Sample data for training programs
sample_data_training = [
    "Platform Overview Tutorial",
    "Advanced Feature Guide",
    "Troubleshooting FAQs",
    "Live Q&A Session",
]

# Add sample data to training programs listbox
for item in sample_data_training:
    training_listbox.insert("end", item)

# Create user support section
support_frame = Frame(sections_frame, bg=BG_COLOR, bd=1, relief="groove")
support_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)

# User support label
support_label = Label(support_frame, text="User Support", font=("Arial", 14, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
support_label.pack(pady=5)

# Radio buttons for contact methods
contact_methods = ["Email", "Chat", "Phone"]
contact_method_var = IntVar()

for i, method in enumerate(contact_methods):
    radio_button = Radiobutton(support_frame, text=method, variable=contact_method_var, value=i, bg=BG_COLOR, fg=TEXT_COLOR)
    radio_button.pack(anchor="w")

# Contact information and support hours
support_info_text = """
For any questions or assistance, please contact us:

Email: support@example.com
Chat: Available online 9:00 AM - 5:00 PM EST
Phone: +1-800-555-HELP

"""
support_info_label = Label(support_frame, text=support_info_text, bg=BG_COLOR, fg=TEXT_COLOR)
support_info_label.pack(pady=10)

# Start the main event loop
root.mainloop()
