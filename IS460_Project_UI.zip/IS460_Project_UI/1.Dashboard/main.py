from tkinter import Tk,ttk, Label, Frame, Button, Listbox, Scrollbar
from flask import Flask

app1 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Dashboard - Recent Communications")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Recent Communications", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create communication list frame
comm_list_frame = Frame(root, bg=BG_COLOR)
comm_list_frame.pack(fill="both", expand=True)

# Create scrollbar
scrollbar = Scrollbar(comm_list_frame, orient="vertical")
scrollbar.pack(side="right", fill="y")

# Create communication listbox
comm_listbox = Listbox(comm_list_frame, bg=BG_COLOR, fg=TEXT_COLOR, selectmode="SINGLE", yscrollcommand=scrollbar.set)
comm_listbox.pack(fill="both", expand=True)

# Configure scrollbar
scrollbar.config(command=comm_listbox.yview)

# Sample data
sample_data = [
    "John Smith - Email: New project proposal",
    "Jane Doe - Chat: Urgent question about deadline",
    "Mark Lee - Phone call: Meeting confirmation",
    "Sarah Jones - Video conference: Team discussion",
]

# Add sample data to listbox
for item in sample_data:
    comm_listbox.insert("end", item)

# Create button frame
button_frame = Frame(root, bg=BG_COLOR)
button_frame.pack(fill="x", side="bottom")

# Create quick access buttons
button1 = Button(button_frame, text="Compose Email", bg=ACCENT_COLOR, fg=TEXT_COLOR)
button1.pack(side="left", padx=10)

button2 = Button(button_frame, text="Start Chat", bg=ACCENT_COLOR, fg=TEXT_COLOR)
button2.pack(side="left", padx=10)

button3 = Button(button_frame, text="Schedule Meeting", bg=ACCENT_COLOR, fg=TEXT_COLOR)
button3.pack(side="left", padx=10)

# Start the main event loop
root.mainloop()
