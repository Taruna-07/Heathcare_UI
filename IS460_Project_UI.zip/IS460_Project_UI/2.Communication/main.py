from tkinter import Tk, Label, Frame, Button, Listbox, Scrollbar, Entry
from flask import Flask

app2 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Communication - Secure Chat, Video Conferencing, Document Sharing")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Communication", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create tabs frame
tabs_frame = Frame(root, bg=BG_COLOR)
tabs_frame.pack(fill="both", expand=True)

# Define tab buttons
chat_button = Button(tabs_frame, text="Chat", bg=BG_COLOR, fg=TEXT_COLOR, font=("Arial", 12))
conference_button = Button(tabs_frame, text="Video Conferencing", bg=BG_COLOR, fg=TEXT_COLOR, font=("Arial", 12))
documents_button = Button(tabs_frame, text="Documents", bg=BG_COLOR, fg=TEXT_COLOR, font=("Arial", 12))

# Position tab buttons
chat_button.pack(side="left", padx=10)
conference_button.pack(side="left", padx=10)
documents_button.pack(side="left", padx=10)

# Create frames for each tab content
chat_frame = Frame(tabs_frame, bg=BG_COLOR)
conference_frame = Frame(tabs_frame, bg=BG_COLOR)
documents_frame = Frame(tabs_frame, bg=BG_COLOR)

# Initially hide other frames except chat
chat_frame.pack(fill="both", expand=True)
conference_frame.pack_forget()
documents_frame.pack_forget()

# Define functions to switch between tabs
def switch_to_chat():
    chat_frame.pack(fill="both", expand=True)
    conference_frame.pack_forget()
    documents_frame.pack_forget()

def switch_to_conference():
    chat_frame.pack_forget()
    conference_frame.pack(fill="both", expand=True)
    documents_frame.pack_forget()

def switch_to_documents():
    chat_frame.pack_forget()
    conference_frame.pack_forget()
    documents_frame.pack(fill="both", expand=True)

# Bind click events to tab buttons
chat_button.config(command=switch_to_chat)
conference_button.config(command=switch_to_conference)
documents_button.config(command=switch_to_documents)

# Create chat frame content
chat_label = Label(chat_frame, text="Secure Chat", font=("Arial", 14), bg=BG_COLOR, fg=TEXT_COLOR)
chat_label.pack(pady=10)

# ... Add chat functionality here ...

# Create video conferencing frame content
conference_label = Label(conference_frame, text="Video Conferencing", font=("Arial", 14), bg=BG_COLOR, fg=TEXT_COLOR)
conference_label.pack(pady=10)

# ... Add video conferencing functionality here ...

# Create document sharing frame content
document_label = Label(documents_frame, text="Document Sharing", font=("Arial", 14), bg=BG_COLOR, fg=TEXT_COLOR)
document_label.pack(pady=10)

# ... Add document sharing functionality here ...

# Start the main event loop
root.mainloop()
