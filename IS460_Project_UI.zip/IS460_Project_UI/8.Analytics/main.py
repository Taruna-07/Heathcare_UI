from tkinter import Tk, Label, Frame, Button, Canvas, Listbox, Scrollbar
from flask import Flask

app8 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Analytics - Dashboard")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Analytics - Dashboard", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create content frame
content_frame = Frame(root, bg=BG_COLOR)
content_frame.pack(fill="both", expand=True)

# Create sub-frames for data sections
# Real-time Analytics
realtime_frame = Frame(content_frame, bg=BG_COLOR)
realtime_frame.pack(fill="both", expand=True, side="left")

# Insights
insights_frame = Frame(content_frame, bg=BG_COLOR)
insights_frame.pack(fill="both", expand=True, side="right")

# Real-time Analytics data (example)
realtime_data = {
    "Most frequent communication channels": [("Email", 40), ("Chat", 30), ("Phone calls", 25)],
    "System resource usage": [("CPU", 70), ("Memory", 60), ("Network", 50)],
}

# Display real-time data
for label, value in realtime_data.items():
    Label(realtime_frame, text=label, font=("Arial", 14, "bold"), bg=BG_COLOR, fg=TEXT_COLOR).pack(pady=5)
    for sublabel, subvalue in value:
        Label(realtime_frame, text=f"{sublabel}: {subvalue}%", font=("Arial", 12), bg=BG_COLOR, fg=TEXT_COLOR).pack()

# Insights data (example)
insights_data = [
    "Increase chat usage for faster communication.",
    "Reduce peak system resource usage during specific times.",
    "Organize communication channels for better organization.",
]

# Display insights
insights_listbox = Listbox(insights_frame, bg=BG_COLOR, fg=TEXT_COLOR)
insights_listbox.pack(fill="both", expand=True)

for item in insights_data:
    insights_listbox.insert("end", item)

# Start the main event loop
root.mainloop()
