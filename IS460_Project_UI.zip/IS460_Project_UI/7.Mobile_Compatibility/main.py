from tkinter import Tk, Label, Frame, Button, Text
from flask import Flask

app7 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Mobile Compatibility")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Mobile Compatibility", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create content frame
content_frame = Frame(root, bg=BG_COLOR)
content_frame.pack(fill="both", expand=True)

# Create iOS and Android sections
ios_frame = Frame(content_frame, bg=BG_COLOR, borderwidth=1, relief="solid")
ios_frame.pack(fill="both", expand=True, pady=10)

android_frame = Frame(content_frame, bg=BG_COLOR, borderwidth=1, relief="solid")
android_frame.pack(fill="both", expand=True, pady=10)

# Create iOS information
ios_label_title = Label(ios_frame, text="iOS App", font=("Arial", 16, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
ios_label_title.pack(pady=10)

ios_text_info = Text(ios_frame, bg=BG_COLOR, fg=TEXT_COLOR, wrap="word", height=5)
ios_text_info.insert("end", "Download the iOS app from the App Store.")
ios_text_info.pack(pady=5)

# Create Android information
android_label_title = Label(android_frame, text="Android App", font=("Arial", 16, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
android_label_title.pack(pady=10)

android_text_info = Text(android_frame, bg=BG_COLOR, fg=TEXT_COLOR, wrap="word", height=5)
android_text_info.insert("end", "Download the Android app from the Google Play Store.")
android_text_info.pack(pady=5)

# Start the main event loop
root.mainloop()
