from tkinter import Tk, Label, Frame, Text, Checkbutton, Button
from flask import Flask

app9 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Disaster Recovery")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Disaster Recovery", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create redundancy frame
redundancy_frame = Frame(root, bg=BG_COLOR)
redundancy_frame.pack(fill="both", expand=True)

# Create redundancy title and text
redundancy_title = Label(redundancy_frame, text="Redundancy Measures:", font=("Arial", 14, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
redundancy_title.pack(pady=10)

redundancy_text = Text(redundancy_frame, bg=BG_COLOR, fg=TEXT_COLOR, height=10, wrap="word")
redundancy_text.pack(fill="both", expand=True)

# Sample redundancy measures
redundancy_measures = [
    "Data backups to multiple locations (cloud and local)",
    "Redundant hardware components (servers, storage)",
    "Software redundancy with failover capabilities",
    "Regular disaster recovery drills and testing",
]

# Insert sample data into text widget
redundancy_text.insert("end", "\n".join(redundancy_measures))

# Create recovery plan frame
recovery_plan_frame = Frame(root, bg=BG_COLOR)
recovery_plan_frame.pack(fill="both", expand=True)

# Create recovery plan title and text
recovery_plan_title = Label(recovery_plan_frame, text="Recovery Plan:", font=("Arial", 14, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
recovery_plan_title.pack(pady=10)

recovery_plan_text = Text(recovery_plan_frame, bg=BG_COLOR, fg=TEXT_COLOR, height=10, wrap="word")
recovery_plan_text.pack(fill="both", expand=True)

# Sample recovery plan steps
recovery_plan_steps = [
    "Identify critical systems and data.",
    "Define roles and responsibilities for recovery team.",
    "Establish communication protocols during recovery.",
    "Develop procedures for restoring systems and data.",
    "Test and update the recovery plan regularly.",
]

# Insert sample data into text widget
recovery_plan_text.insert("end", "\n".join(recovery_plan_steps))

# Create button frame
button_frame = Frame(root, bg=BG_COLOR)
button_frame.pack(fill="x", side="bottom")

# Create button to test the recovery plan
test_button = Button(button_frame, text="Test Recovery Plan", bg=ACCENT_COLOR, fg=TEXT_COLOR)
test_button.pack(side="right", padx=10)

# Create checkbutton to confirm understanding of the plan
acknowledge_button = Checkbutton(button_frame, text="I acknowledge understanding the recovery plan.", bg=BG_COLOR, fg=TEXT_COLOR)
acknowledge_button.pack(side="left", padx=10)

# Start the main event loop
root.mainloop()
