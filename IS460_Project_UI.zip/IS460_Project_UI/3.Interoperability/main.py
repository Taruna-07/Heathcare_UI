from tkinter import Tk, Label, Frame, Button, Text, Scrollbar
from flask import Flask

app3 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Interoperability - Integration and Data Exchange")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Interoperability", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create content frame
content_frame = Frame(root, bg=BG_COLOR)
content_frame.pack(fill="both", expand=True)

# Create integration protocols frame
protocols_frame = Frame(content_frame, bg=BG_COLOR, bd=1, relief="groove")
protocols_frame.pack(fill="x", padx=20, pady=10)

# Create protocols label
protocols_label = Label(protocols_frame, text="Integration Protocols:", font=("Arial", 14, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
protocols_label.pack(pady=10)

# Create protocols text
protocols_text = Text(protocols_frame, bg=BG_COLOR, fg=TEXT_COLOR, width=50, height=5, wrap="word")
protocols_text.insert("end", "• HL7 (Health Level Seven): Standard for exchanging healthcare data between different systems.\n• FHIR (Fast Healthcare Interoperability Resources): Modern API-based approach for healthcare data exchange.")
protocols_text.configure(state="disabled")
protocols_text.pack(pady=10)

# Create data interchange frame
data_frame = Frame(content_frame, bg=BG_COLOR, bd=1, relief="groove")
data_frame.pack(fill="x", padx=20, pady=10)

# Create data label
data_label = Label(data_frame, text="Data Interchange:", font=("Arial", 14, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
data_label.pack(pady=10)

# Create data text
data_text = Text(data_frame, bg=BG_COLOR, fg=TEXT_COLOR, width=50, height=5, wrap="word")
data_text.insert("end", "• Share patient data: Demographics, medical history, allergies, medications.\n• Exchange test findings: Lab results, imaging reports, pathology reports.\n• Coordinate treatment plans: Care plans, referrals, prescriptions.\n• Ensure compatibility with various healthcare information systems.")
data_text.configure(state="disabled")
data_text.pack(pady=10)

# Start the main event loop
root.mainloop()
