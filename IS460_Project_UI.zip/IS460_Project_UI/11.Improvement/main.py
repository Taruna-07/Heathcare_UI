from tkinter import Tk, Label, Frame, Entry, Button, Listbox, Scrollbar, Checkbutton, IntVar, StringVar
from flask import Flask

app11 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Continuous Improvement - User Feedback & Metrics")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Continuous Improvement", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create user feedback frame
feedback_frame = Frame(root, bg=BG_COLOR)
feedback_frame.pack(fill="both", expand=True)

# Label for feedback input
feedback_label = Label(feedback_frame, text="Provide Feedback:", bg=BG_COLOR, fg=TEXT_COLOR)
feedback_label.pack(pady=10)

# Entry box for user feedback
feedback_entry = Entry(feedback_frame, bg="white", fg=TEXT_COLOR, width=50)
feedback_entry.pack(pady=10)

# Button to submit feedback
feedback_button = Button(feedback_frame, text="Submit Feedback", bg=ACCENT_COLOR, fg=TEXT_COLOR, command=lambda: save_feedback(feedback_entry.get()))
feedback_button.pack(pady=10)

# Create performance metrics frame
metrics_frame = Frame(root, bg=BG_COLOR)
metrics_frame.pack(fill="both", expand=True)

# Label for performance metrics
metrics_label = Label(metrics_frame, text="Performance Metrics:", bg=BG_COLOR, fg=TEXT_COLOR)
metrics_label.pack(pady=10)

# Sample performance metrics
metric_names = ["Average Response Time", "Error Rate", "User Satisfaction", "Feature Utilization"]
metric_values = ["2 minutes", "1%", "85%", "70%"]

# Create checkboxes and labels for performance metrics
metric_checkboxes = {}
for i, (name, value) in enumerate(zip(metric_names, metric_values)):
    var = IntVar()
    metric_checkbox = Checkbutton(metrics_frame, text=f"{name}: {value}", bg=BG_COLOR, fg=TEXT_COLOR, variable=var)
    metric_checkbox.pack(anchor="w")
    metric_checkboxes[name] = var

# Button to analyze performance
analyze_button = Button(metrics_frame, text="Analyze Performance", bg=ACCENT_COLOR, fg=TEXT_COLOR)
analyze_button.pack(pady=10)

# Function to save user feedback
def save_feedback(feedback):
    print(f"User feedback: {feedback}")

# Start the main event loop
root.mainloop()
